Här kan effects och animeringar bo
