Här får componenter bo!
