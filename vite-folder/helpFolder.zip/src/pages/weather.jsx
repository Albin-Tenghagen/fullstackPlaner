function Weather() {
  return (
    <>
      <h3>Det är skitit väder, som fan</h3>
    </>
  );
}

export default Weather;
