import Navbar from "../NavbarFolder/navbar";

function Header() {
  return (
    <header>
      <p>Hello World</p>

      <Navbar />
    </header>
  );
}

export default Header;
