Här får componenter bo!
